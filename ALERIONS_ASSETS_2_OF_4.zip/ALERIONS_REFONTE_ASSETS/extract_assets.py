from pathlib import Path
from PIL import Image
import json
root=Path(__file__).resolve().parent
for page,crops in json.loads((root/'06_SPECIFICATIONS/decoupes.json').read_text()).items():
    im=Image.open(root/'01_MAQUETTES'/f'{page}-desktop-1536x1024.png')
    dest=root/'04_EXTRACTIONS_EXACTES'/page
    dest.mkdir(parents=True,exist_ok=True)
    for name,box in crops.items(): im.crop(box).save(dest/f'{name}.png')
print('31 exact crops created')
