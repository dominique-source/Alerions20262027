ALERIONS CHAT — VERSION IMAGEE

1. Extraire le ZIP dans le depot Alerions20262027.
2. Ouvrir les deux maquettes originales.
3. Copier PROMPT_CLAUDE.txt dans Claude Code.
4. Claude ajoute l acces depuis chaque equipe et un apercu responsive.
5. Examiner les captures avant tout deploiement.

Aucun vrai chat, compte joueur ou stockage de messages a implementer maintenant. La version fonctionnelle suivra l ajout des joueurs. Les noms et non-lus affiches sont des exemples fictifs.
